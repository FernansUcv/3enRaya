ponerFondo("espacio");
var p1=new Objeto("blanco");
  p1.ancho=5;
  p1.alto=20;
  p1.x=5;
  p1.y=50;
  p1.puedeChocar=true;
var puntos1=0
var t1=new Texto(puntos1);
  t1.color="red";
  t1.tamanyo=20;
  t1.x=0; t1.ancho=10;
  t1.y=2; t1.alto=5;
var p2=new Objeto("blanco");
  p2.ancho=5;
  p2.alto=20;
  p2.x=95;
  p2.y=50;
  p2.puedeChocar=true;
var puntos2=0;
var t2=new Texto(puntos2);
  t2.color="red";
  t2.tamanyo=20;
  t2.x=90; t2.ancho=10;
  t2.y=2; t2.alto=5;
var pelota=new Objeto("blanco");
  pelota.ancho=pelota.alto=5;
  pelota.puedeChocar=true;
  pelota.puedeRebotar=true;
function lanzarPelota(direccion=1) {
	pelota.x=pelota.y=50;
	pelota.velocidadY=0.25;
	pelota.velocidadX=direccion*0.5;
 pvx=pelota.velocidadX; pvy=pelota.velocidadY;
}
var sonido=new Sonido("premio");
var rebote=new Sonido("pop");
var pvx, pvy; // guardo la dirección anterior de la pelota, para saber cuando cambia (rebota)

teclado.detectarContinuo=true;
function paso() {
 // manejar las palas de cada jugador
	if (teclado.w) p1.mover(0,-1);
	if (teclado.s) p1.mover(0,1);
	if (teclado.arriba) p2.mover(0,-1);
	if (teclado.abajo) p2.mover(0,1);
	// comprobar si la pelota toca los lados
	if (pelota.x<5) { // lado izquierdo, gana jugador 2
	 sonido.sonar();
		puntos2=puntos2+1;
		t2.texto=puntos2;
		avisar("Punto para el jugador 2");
		p1.y=p2.y=50; // centrar de nuevo
		lanzarPelota(-1); // lanzar hacia la izquierda
	}
	if (pelota.x>95) { // lado derecho, gana jugador 1
	 sonido.sonar();
		puntos1=puntos1+1;
		t1.texto=puntos1;
		avisar("Punto para el jugador 1");
		p1.y=p2.y=50; // centrar de nuevo
		lanzarPelota(1); // lanzar hacia la derecha
	}
	// comprobar rebotes de la pelota (para el sonido)
	if (pelota.velocidadX!=pvx || pelota.velocidadY!=pvy) rebote.sonar();
 pvx=pelota.velocidadX; pvy=pelota.velocidadY;
}
avisar("A jugar!!!");
lanzarPelota(1);
iniciar();

"a jugar!!!";