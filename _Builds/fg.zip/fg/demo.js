rojo=new Objeto("rojo");
rojo.x=25;
rojo.velocidadX=1;
rojo.puedeChocar=true;
rojo.puedeRebotar=true;
verde=new Objeto("verde");
verde.puedeChocar=true;
azul=new Objeto("azul");
azul.y=75;
azul.velocidadY=-1;
azul.velocidadX=1;
azul.puedeChocar=true;
azul.gravedad=true;
azul.puedeRebotar=true;
amarillo=new Objeto("amarillo");
amarillo.y=25;
amarillo.puedeChocar=true;
amarillo.velocidadY=-1;
negro=new Objeto("negro");
function paso() {
  if (teclado.derecha) negro.mover(1,0);
  if (teclado.izquierda) negro.mover(-1,0);
  if (teclado.arriba) negro.mover(0,-1);
  if (teclado.abajo) negro.mover(0,1);
  if (raton.boton && rojo.estaChocando(raton.x, raton.y)) escribir("pulsar en el rojo");
}