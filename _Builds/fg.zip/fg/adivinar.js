elegido=aleatorio()
for (intentos=10;intentos>0;intentos--) {
  numero=preguntar("Dime un número entre 0 y 100");
  if (elegido>numero) avisar("debe ser mayor");
  if (elegido<numero) avisar("debe ser menor");
  if (elegido==numero) {
    avisar("Has ganado");
    break;
  }
}
if (intentos==0) {
  avisar("Has perdido. El elegido era "+elegido);
}
