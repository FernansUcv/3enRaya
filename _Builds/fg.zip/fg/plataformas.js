ponerFondo("cielo");
var suelo=new Objeto("cesped");
suelo.ancho=100;
suelo.alto=10;
suelo.x=50;
suelo.y=95;
suelo.puedeChocar=true;

var plataforma1=new Objeto("ladrillos");
plataforma1.ancho=20;
plataforma1.alto=5;
plataforma1.x=75;
plataforma1.y=75;
plataforma1.puedeChocar=true;
var plataforma2=new Objeto("ladrillos");
plataforma2.ancho=10;
plataforma2.alto=5;
plataforma2.x=40;
plataforma2.y=60;
plataforma2.puedeChocar=true;
var plataforma3=new Objeto("ladrillos");
plataforma3.ancho=20;
plataforma3.alto=5;
plataforma3.x=25;
plataforma3.y=40;
plataforma3.puedeChocar=true;
var plataforma4=new Objeto("ladrillos");
plataforma4.ancho=20;
plataforma4.alto=5;
plataforma4.x=70;
plataforma4.y=25;
plataforma4.puedeChocar=true;

var moneda=new Objeto("moneda");
moneda.x=70;
moneda.y=20;
moneda.ancho=moneda.alto=5;
moneda.puedeChocar=true;
moneda.puedeRebotar=true;
moneda.gravedad=true;
moneda.velocidadY=-1;

var personaje=new Objeto("pirata");
personaje.x=50;
personaje.y=85;
personaje.puedeChocar=true;
personaje.gravedad=true;
var salto=new Sonido("pop");
var premio=new Sonido("premio");
var musica=new Sonido("musica1.mp3");
musica.repetir=true;
musica.volumen=50;
musica.sonar();

teclado.detectarContinuo=true;
function paso() {
 if (teclado.derecha) {
   personaje.mover(1,0);
   personaje.espejoHorizontal=false;
 }
 if (teclado.izquierda) {
   personaje.mover(-1,0);
   personaje.espejoHorizontal=true;
 }
 if (teclado.espacio || teclado.arriba) {
   if (personaje.velocidadY==0) {
     salto.sonar();
     personaje.velocidadY=-2;
   }
 }
 // comprobar premio
 if (personaje.estaChocando(moneda)) {
   premio.sonar();
   musica.parar();
 	  detener();
 	  avisar("Has ganado");
 }
}

iniciar();
"a jugar...";

